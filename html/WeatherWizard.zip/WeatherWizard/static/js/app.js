document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const searchForm = document.getElementById('search-form');
    const locationInput = document.getElementById('location-input');
    const weatherLoading = document.getElementById('weather-loading');
    const weatherInfo = document.getElementById('weather-info');
    const emptyState = document.getElementById('empty-state');
    const searchError = document.getElementById('search-error');
    const errorMessage = document.getElementById('error-message');
    const detectLocationBtn = document.getElementById('detect-location');
    
    // Weather data elements
    const locationName = document.getElementById('location-name');
    const localTime = document.getElementById('local-time');
    const temperature = document.getElementById('temperature');
    const conditionText = document.getElementById('condition-text');
    const conditionIcon = document.getElementById('condition-icon');
    const humidity = document.getElementById('humidity');
    const windSpeed = document.getElementById('wind-speed');
    const windDirection = document.getElementById('wind-direction');
    const visibility = document.getElementById('visibility');
    const feelsLike = document.getElementById('feels-like');
    const pressure = document.getElementById('pressure');
    const cloud = document.getElementById('cloud');
    const uv = document.getElementById('uv');

    // Weather condition codes to background mapping
    const weatherBackgrounds = {
        // Sunny - 1000 (day)
        sunny: [1000],
        // Cloudy conditions
        cloudy: [1003, 1006, 1009, 1030],
        // Rainy conditions
        rainy: [1063, 1069, 1072, 1150, 1153, 1168, 1171, 1180, 1183, 1186, 1189, 1192, 1195, 1198, 1201, 1240, 1243, 1246],
        // Snowy conditions
        snowy: [1066, 1114, 1117, 1210, 1213, 1216, 1219, 1222, 1225, 1255, 1258, 1279, 1282],
        // Storm conditions
        stormy: [1087, 1273, 1276, 1279, 1282],
        // Foggy conditions
        foggy: [1135, 1147]
    };

    // Handle search form submission
    searchForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const location = locationInput.value.trim();
        
        if (location) {
            // Show loading indicator
            showLoading();
            
            // Fetch weather data
            fetchWeatherData(location);
        }
    });
    
    // Handle detect location button click
    detectLocationBtn.addEventListener('click', function() {
        if (navigator.geolocation) {
            detectLocationBtn.disabled = true;
            detectLocationBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i> Detecting...';
            
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    const latitude = position.coords.latitude;
                    const longitude = position.coords.longitude;
                    showLoading();
                    fetchWeatherData(`${latitude},${longitude}`);
                    detectLocationBtn.disabled = false;
                    detectLocationBtn.innerHTML = '<i class="fas fa-location-arrow me-2"></i> Use Current Location';
                },
                (error) => {
                    console.log('Geolocation error:', error);
                    showError('Unable to access your location. Please check your browser settings or enter a location manually.');
                    detectLocationBtn.disabled = false;
                    detectLocationBtn.innerHTML = '<i class="fas fa-location-arrow me-2"></i> Use Current Location';
                },
                {
                    enableHighAccuracy: true,
                    timeout: 10000,
                    maximumAge: 0
                }
            );
        } else {
            showError('Geolocation is not supported by your browser. Please enter a location manually.');
        }
    });

    // Function to show loading indicator
    function showLoading() {
        weatherInfo.classList.add('d-none');
        emptyState.classList.add('d-none');
        searchError.classList.add('d-none');
        weatherLoading.classList.remove('d-none');
    }

    // Function to show weather information
    function showWeatherInfo() {
        weatherLoading.classList.add('d-none');
        emptyState.classList.add('d-none');
        searchError.classList.add('d-none');
        weatherInfo.classList.remove('d-none');
    }

    // Function to show error message
    function showError(message) {
        weatherLoading.classList.add('d-none');
        weatherInfo.classList.add('d-none');
        emptyState.classList.remove('d-none');
        searchError.classList.remove('d-none');
        errorMessage.textContent = message;
    }

    // Function to fetch weather data
    function fetchWeatherData(location) {
        // Check if API key is available
        if (!API_KEY) {
            showError('API key is not available. Please check your environment variables.');
            return;
        }

        const apiUrl = `https://api.weatherapi.com/v1/current.json?key=${API_KEY}&q=${encodeURIComponent(location)}`;
        
        fetch(apiUrl)
            .then(response => {
                if (!response.ok) {
                    throw new Error(`Error: ${response.status} - ${response.statusText}`);
                }
                return response.json();
            })
            .then(data => {
                updateWeatherUI(data);
            })
            .catch(error => {
                console.error('Error fetching weather data:', error);
                
                // Show appropriate error message
                if (error.message.includes('404')) {
                    showError('Location not found. Please check the city name and try again.');
                } else {
                    showError('Failed to fetch weather data. Please try again later.');
                }
            });
    }

    // Function to update the UI with weather data
    function updateWeatherUI(data) {
        const current = data.current;
        const location = data.location;
        
        // Set location information
        locationName.textContent = `${location.name}, ${location.country}`;
        
        // Format local time
        const localTimeDate = new Date(location.localtime);
        const timeOptions = { 
            hour: 'numeric', 
            minute: 'numeric', 
            hour12: true,
            weekday: 'long',
            year: 'numeric', 
            month: 'long', 
            day: 'numeric'
        };
        localTime.textContent = localTimeDate.toLocaleString(undefined, timeOptions);
        
        // Set temperature and condition
        temperature.textContent = `${Math.round(current.temp_c)}°C`;
        conditionText.textContent = current.condition.text;
        conditionIcon.src = `https:${current.condition.icon}`;
        conditionIcon.alt = current.condition.text;
        
        // Set weather details
        humidity.textContent = `${current.humidity}%`;
        windSpeed.textContent = `${current.wind_kph} km/h`;
        windDirection.textContent = current.wind_dir;
        visibility.textContent = `${current.vis_km} km`;
        feelsLike.textContent = `${Math.round(current.feelslike_c)}°C`;
        pressure.textContent = `${current.pressure_mb} hPa`;
        cloud.textContent = `${current.cloud}%`;
        
        // Set UV index with text description
        const uvValue = current.uv;
        let uvText = 'Low';
        
        if (uvValue >= 3 && uvValue < 6) {
            uvText = 'Moderate';
        } else if (uvValue >= 6 && uvValue < 8) {
            uvText = 'High';
        } else if (uvValue >= 8 && uvValue < 11) {
            uvText = 'Very High';
        } else if (uvValue >= 11) {
            uvText = 'Extreme';
        }
        
        uv.textContent = `${uvValue} (${uvText})`;
        
        // Update background based on weather condition and time
        updateBackground(current.condition.code, current.is_day);
        
        // Show weather information
        showWeatherInfo();
    }

    // Function to update background based on weather condition
    function updateBackground(conditionCode, isDay) {
        // Remove all weather background classes
        document.body.classList.remove('sunny', 'cloudy', 'rainy', 'snowy', 'stormy', 'foggy', 'night');
        
        // Set background based on condition code and day/night
        if (!isDay) {
            document.body.classList.add('night');
            return;
        }
        
        // Find the matching weather type
        for (const [type, codes] of Object.entries(weatherBackgrounds)) {
            if (codes.includes(conditionCode)) {
                document.body.classList.add(type);
                return;
            }
        }
        
        // Default to sunny if no match
        document.body.classList.add('sunny');
    }

    // Try to get user's location for initial weather if supported
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                const latitude = position.coords.latitude;
                const longitude = position.coords.longitude;
                showLoading();
                fetchWeatherData(`${latitude},${longitude}`);
            },
            (error) => {
                console.log('Geolocation error:', error);
                // Don't show an error, just keep the empty state
            }
        );
    }
});

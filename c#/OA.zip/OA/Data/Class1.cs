﻿namespace Data
{
    public class Class1
    {

    }
}

﻿namespace Web.Models
{
    public class DeleteUserViewModel
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
    }
}
